package com.example.MobileShop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MobileShopApplicationTests {

	@Test
	void contextLoads() {
	}

}
